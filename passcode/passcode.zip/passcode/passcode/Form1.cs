﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace passcode
{
    public partial class Form1 : Form
    {
        private readonly List<int> correct_state;
        private List<int> vars;
        private List<int> indices;
        private List<int> state;

        public Form1()
        {
            InitializeComponent();
            correct_state = (from c in "231947329526721682516992571486892842339532472728294975864291475665969671246186815549145112147349184871155162521147273481838" select (int)(c - '0')).ToList();
            debug();
            reset();
        }

        private void reset()
        {
            vars = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            indices = new List<int>();
            state = new List<int>();
        }

        private void shuffle()
        {
            int seed = 0;
            foreach (int x in state)
            {
                seed = seed * 10 + x;
            }
            Random rng = new Random(seed);
            for (int i = 0; i < 9; i++)
            {
                int j = rng.Next(9);
                int tmp = vars[i];
                vars[i] = vars[j];
                vars[j] = tmp;
            }
        }

        private void push(int index)
        {
            indices.Add(index);
            state.Add(vars[index]);
            shuffle();

            if (state.SequenceEqual(correct_state))
            {
                string flag = "";
                for (int i = 0; i < indices.Count / 3; i++)
                {
                    flag += (char)(indices[i * 3] * 64 + indices[i * 3 + 1] * 8 + indices[i * 3 + 2]);
                }
                MessageBox.Show(flag, "Correct!");
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            int index = int.Parse(((Button)sender).Name.Substring(6)) - 1;
            push(index);
        }

        private void Button10_Click(object sender, EventArgs e)
        {
            reset();
        }

        private void debug()
        {
#if DEBUG
            //f = "KosenCTF{pr3tty_3asy_r3v3rsing_cha11enge}"
            //of = ""
            //for c in f:
            //    of += "{:03o}".format(ord(c))
            //print(of)
            //f2 = ""
            //for i in range(len(of) // 3):
            //    f2 += chr(int(of[i * 3:i * 3 + 3], 8))
            //print(f2)

            string indices_as_oct = "113157163145156103124106173160162063164164171137063141163171137162063166063162163151156147137143150141061061145156147145175";
            reset();
            for (int i = 0; i < indices_as_oct.Length; i++)
            {
                int index = int.Parse(indices_as_oct[i] + "");
                indices.Add(index);
                state.Add(vars[index]);
                shuffle();
            }
            foreach (var x in state)
            {
                Console.Write("{0}", x);
            }
            Console.WriteLine();
            foreach (var x in correct_state)
            {
                Console.Write("{0}", x);
            }
            Console.WriteLine();
            reset();

            foreach (var x in correct_state)
            {
                var index = vars.IndexOf(x);
                push(index);
            }
#endif
        }
    }
}
